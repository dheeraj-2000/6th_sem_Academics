**Problem Statement:**

Cab company is facing problem of driver initiated cancellation and non-availability of cabs from cab booking application leading to loss of potential revenue. 

**Goal of assignment:**

1. Analyse given data to identify the root cause of the problem (i.e. cancellation and non-availability of cars) & and present possible hypotheses of the problem.
2. Recommend ways to improve this situation.
