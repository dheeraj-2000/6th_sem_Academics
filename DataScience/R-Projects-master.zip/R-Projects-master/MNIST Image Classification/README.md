**Problem Statement**

Develop a model that can correctly identify the digit(between 0-9) written in an image of handwritten digit from MNIST database.
