**Problem Statement**

A consumer finance company which specialises in lending various types of loans to urban customers wants to understand the driving factors (or driver variables) behind loan default as this knowledge can help them for their portfolio and risk assessment.
